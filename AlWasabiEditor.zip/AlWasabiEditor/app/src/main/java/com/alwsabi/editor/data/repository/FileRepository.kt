package com.alwsabi.editor.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.alwsabi.editor.data.model.FileOperationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * المسؤول عن جميع عمليات قراءة وكتابة ومشاركة الملفات باستخدام
 * Storage Access Framework (SAF)، بدون أي صلاحيات تخزين قديمة.
 */
class FileRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    /**
     * يقرأ محتوى نصي كامل من Uri تم اختياره عبر SAF.
     * يعيد null في حال فشل القراءة (بدون تعطل التطبيق).
     */
    suspend fun readTextFromUri(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val text = resolver.openInputStream(uri)?.use { stream ->
                stream.bufferedReader(Charsets.UTF_8).readText()
            } ?: return@withContext Result.failure(IllegalStateException("تعذر فتح الملف"))
            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * يكتب نصًا كاملاً إلى Uri موجود (يُستخدم في "حفظ" على ملف مفتوح مسبقًا).
     */
    suspend fun writeTextToUri(uri: Uri, content: String): FileOperationResult =
        withContext(Dispatchers.IO) {
            try {
                resolver.openOutputStream(uri, "wt")?.use { stream ->
                    stream.write(content.toByteArray(Charsets.UTF_8))
                    stream.flush()
                } ?: return@withContext FileOperationResult.Failure("تعذر فتح مسار الحفظ")
                FileOperationResult.Success()
            } catch (e: Exception) {
                FileOperationResult.Failure(e.message ?: "خطأ غير معروف أثناء الحفظ")
            }
        }

    /**
     * يستخرج اسم العرض (display name) من Uri عبر ContentResolver.
     */
    fun queryDisplayName(uri: Uri): String {
        var name = "مستند بدون عنوان"
        try {
            val cursor: Cursor? = resolver.query(uri, null, null, null, null)
            cursor?.use {
                val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && it.moveToFirst()) {
                    name = it.getString(nameIndex) ?: name
                }
            }
        } catch (_: Exception) {
            // تجاهل، سيتم استخدام الاسم الافتراضي
        }
        return name
    }

    /**
     * يعيد تسمية ملف موجود عبر DocumentsContract إذا كان مدعومًا.
     */
    suspend fun renameDocument(uri: Uri, newName: String): FileOperationResult =
        withContext(Dispatchers.IO) {
            try {
                val result = android.provider.DocumentsContract.renameDocument(
                    resolver, uri, newName
                )
                if (result != null) {
                    FileOperationResult.Success()
                } else {
                    FileOperationResult.Failure("تعذرت إعادة التسمية")
                }
            } catch (e: Exception) {
                FileOperationResult.Failure(e.message ?: "تعذرت إعادة التسمية")
            }
        }

    /**
     * يحذف ملفًا عبر DocumentsContract.
     */
    suspend fun deleteDocument(uri: Uri): FileOperationResult = withContext(Dispatchers.IO) {
        try {
            val deleted = android.provider.DocumentsContract.deleteDocument(resolver, uri)
            if (deleted) {
                FileOperationResult.Success()
            } else {
                FileOperationResult.Failure("تعذر حذف الملف")
            }
        } catch (e: Exception) {
            FileOperationResult.Failure(e.message ?: "تعذر حذف الملف")
        }
    }

    /**
     * ينسخ محتوى نصي إلى ملف مؤقت داخل cache ثم يعيد Uri آمن للمشاركة
     * عبر FileProvider (بدون الحاجة لصلاحيات تخزين خارجي).
     */
    suspend fun createShareableFile(content: String, fileName: String): Uri? =
        withContext(Dispatchers.IO) {
            try {
                val sharedDir = File(context.cacheDir, "shared").apply { mkdirs() }
                val outFile = File(sharedDir, fileName)
                FileOutputStream(outFile).use { it.write(content.toByteArray(Charsets.UTF_8)) }
                FileProvider.getUriForFile(context, "com.alwsabi.editor.fileprovider", outFile)
            } catch (_: Exception) {
                null
            }
        }

    /**
     * يبني Intent مشاركة جاهزًا لملف عبر Uri آمن.
     */
    fun buildShareIntent(uri: Uri, mimeType: String): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /**
     * ينسخ ملف PDF ناتج داخل التخزين المؤقت إلى Uri آمن للمشاركة/العرض.
     */
    suspend fun getUriForCacheFile(file: File): Uri = withContext(Dispatchers.IO) {
        FileProvider.getUriForFile(context, "com.alwsabi.editor.fileprovider", file)
    }
}
