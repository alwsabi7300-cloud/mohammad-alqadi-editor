package com.alwsabi.editor.ui.screens.pdf

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.alwsabi.editor.R
import com.alwsabi.editor.data.pdf.PdfPageRenderer
import com.alwsabi.editor.ui.components.AppTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    pdfUri: String,
    onNavigateBack: () -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    var pageBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pdfUri) {
        isLoading = true
        errorMessage = null
        val renderer = PdfPageRenderer(context)
        val targetWidthPx = with(density) { 360.dp.toPx() }.toInt().coerceAtLeast(300)

        val openResult = renderer.open(Uri.parse(pdfUri))
        openResult.fold(
            onSuccess = { pageCount ->
                val bitmaps = mutableListOf<Bitmap>()
                for (i in 0 until pageCount) {
                    val pageResult = renderer.renderPage(i, targetWidthPx)
                    pageResult.onSuccess { bitmaps.add(it) }
                }
                pageBitmaps = bitmaps
                isLoading = false
            },
            onFailure = {
                errorMessage = context.getString(R.string.pdf_viewer_error)
                isLoading = false
            }
        )
        renderer.close()
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.pdf_viewer_title),
                showBackButton = true,
                onBackClick = onNavigateBack,
                actions = {
                    IconButton(onClick = onShare) {
                        Icon(Icons.Default.Share, contentDescription = stringResource(R.string.pdf_viewer_share))
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.Center
        ) {
            when {
                isLoading -> CircularProgressIndicator()
                errorMessage != null -> Text(errorMessage ?: "", style = MaterialTheme.typography.bodyLarge)
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
                ) {
                    items(pageBitmaps.size) { index ->
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Image(
                                bitmap = pageBitmaps[index].asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = String.format(
                                    stringResource(R.string.pdf_viewer_page),
                                    index + 1,
                                    pageBitmaps.size
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
