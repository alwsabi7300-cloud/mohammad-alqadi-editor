package com.alwsabi.editor.util

import android.text.Html
import android.text.Spannable
import android.text.SpannableStringBuilder

/**
 * تحويل بين النص المنسّق (Spannable) وصيغة HTML لأغراض التصدير/الحفظ
 * بصيغة تحافظ على التنسيق (عريض/مائل/تسطير/لون)، باستخدام Html API
 * الأصلية في أندرويد (مستقرة ومتوفرة منذ زمن طويل).
 */
object RichTextConverter {

    fun spannableToHtml(spannable: Spannable): String {
        return Html.toHtml(spannable, Html.TO_HTML_PARAGRAPH_LINES_CONSECUTIVE)
    }

    @Suppress("DEPRECATION")
    fun htmlToSpannable(html: String): Spannable {
        val spanned = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(html)
        }
        return SpannableStringBuilder(spanned)
    }

    /** يزيل كل التنسيقات ويعيد نصًا خامًا فقط. */
    fun plainTextOf(spannable: CharSequence): String = spannable.toString()
}
