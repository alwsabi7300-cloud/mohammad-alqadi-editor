package com.alwsabi.editor.util

/**
 * أدوات حساب إحصاءات النص: عدد الكلمات وعدد الأحرف.
 * تدعم العربية والإنجليزية معًا عبر تقسيم بسيط على الفراغات.
 */
object TextStatsUtil {

    fun wordCount(text: CharSequence): Int {
        if (text.isBlank()) return 0
        return text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
    }

    fun charCount(text: CharSequence): Int = text.length

    fun charCountNoSpaces(text: CharSequence): Int = text.count { !it.isWhitespace() }
}
