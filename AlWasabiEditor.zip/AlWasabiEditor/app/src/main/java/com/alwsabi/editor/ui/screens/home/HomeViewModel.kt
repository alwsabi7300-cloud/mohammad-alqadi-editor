package com.alwsabi.editor.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alwsabi.editor.data.model.RecentDocument
import com.alwsabi.editor.data.repository.RecentFilesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val recentFilesRepository = RecentFilesRepository(application)

    val recentFiles: StateFlow<List<RecentDocument>> = recentFilesRepository.recentFilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun removeRecent(uriString: String) {
        viewModelScope.launch {
            recentFilesRepository.remove(uriString)
        }
    }
}
