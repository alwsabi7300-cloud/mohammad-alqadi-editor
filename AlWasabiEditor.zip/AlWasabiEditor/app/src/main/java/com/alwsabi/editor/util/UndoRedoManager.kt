package com.alwsabi.editor.util

import android.text.SpannableStringBuilder

/**
 * مدير تراجع/إعادة بسيط ومستقر يحتفظ بلقطات (snapshots) من نص المحرر
 * المنسّق (SpannableStringBuilder) على شكل نص مع علامات HTML داخلية خفيفة
 * (يُستخدم فقط لالتقاط الحالة، وليس للتخزين النهائي).
 *
 * لتفادي استهلاك ذاكرة كبير، يتم الاحتفاظ بحد أقصى من اللقطات فقط.
 */
class UndoRedoManager(private val maxHistory: Int = 60) {

    private val undoStack = ArrayDeque<CharSequence>()
    private val redoStack = ArrayDeque<CharSequence>()
    private var isRestoring = false
    private var lastPushedAt = 0L
    private val debounceMillis = 400L

    fun canUndo(): Boolean = undoStack.size > 1
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    /** يبدأ السجل بلقطة أولية (عند فتح/إنشاء مستند). */
    fun initialize(initial: CharSequence) {
        undoStack.clear()
        redoStack.clear()
        undoStack.addLast(SpannableStringBuilder(initial))
    }

    /** يسجّل الحالة الحالية كلقطة جديدة إذا كانت العملية ليست استعادة (undo/redo). */
    fun push(current: CharSequence) {
        if (isRestoring) return
        val now = System.currentTimeMillis()
        if (now - lastPushedAt < debounceMillis && undoStack.isNotEmpty()) {
            // استبدال آخر لقطة بدل إضافة كل ضغطة زر لتفادي سجل ضخم
            undoStack.removeLast()
        }
        lastPushedAt = now
        undoStack.addLast(SpannableStringBuilder(current))
        if (undoStack.size > maxHistory) {
            undoStack.removeFirst()
        }
        redoStack.clear()
    }

    /** يعيد اللقطة السابقة، أو null إذا لم يوجد شيء للتراجع عنه. */
    fun undo(): CharSequence? {
        if (!canUndo()) return null
        isRestoring = true
        val current = undoStack.removeLast()
        redoStack.addLast(current)
        val previous = undoStack.last()
        isRestoring = false
        return SpannableStringBuilder(previous)
    }

    /** يعيد تطبيق آخر عملية تراجع عنها المستخدم. */
    fun redo(): CharSequence? {
        if (!canRedo()) return null
        isRestoring = true
        val redoState = redoStack.removeLast()
        undoStack.addLast(redoState)
        isRestoring = false
        return SpannableStringBuilder(redoState)
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}
