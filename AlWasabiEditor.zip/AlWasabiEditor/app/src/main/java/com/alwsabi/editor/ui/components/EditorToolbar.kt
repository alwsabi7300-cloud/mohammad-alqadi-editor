package com.alwsabi.editor.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * شريط أدوات التنسيق الأفقي القابل للتمرير أعلى لوحة المفاتيح.
 * كل زر يمثل عملية تنسيق حقيقية تُطبَّق على النص المحدد.
 */
@Composable
fun EditorToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onBold: () -> Unit,
    onItalic: () -> Unit,
    onUnderline: () -> Unit,
    onAlignRight: () -> Unit,
    onAlignCenter: () -> Unit,
    onAlignLeft: () -> Unit,
    onTextColor: () -> Unit,
    onBackgroundColor: () -> Unit,
    onIncreaseFont: () -> Unit,
    onDecreaseFont: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        tonalElevation = 3.dp
    ) {
        androidx.compose.foundation.layout.Column {
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                IconButton(onClick = onUndo, enabled = canUndo) {
                    Icon(Icons.Default.Undo, contentDescription = "تراجع")
                }
                IconButton(onClick = onRedo, enabled = canRedo) {
                    Icon(Icons.Default.Redo, contentDescription = "إعادة")
                }
                IconButton(onClick = onBold) {
                    Icon(Icons.Default.FormatBold, contentDescription = "عريض")
                }
                IconButton(onClick = onItalic) {
                    Icon(Icons.Default.FormatItalic, contentDescription = "مائل")
                }
                IconButton(onClick = onUnderline) {
                    Icon(Icons.Default.FormatUnderlined, contentDescription = "تسطير")
                }
                IconButton(onClick = onAlignRight) {
                    Icon(Icons.Default.FormatAlignRight, contentDescription = "محاذاة يمين")
                }
                IconButton(onClick = onAlignCenter) {
                    Icon(Icons.Default.FormatAlignCenter, contentDescription = "محاذاة وسط")
                }
                IconButton(onClick = onAlignLeft) {
                    Icon(Icons.Default.FormatAlignLeft, contentDescription = "محاذاة يسار")
                }
                IconButton(onClick = onTextColor) {
                    Icon(Icons.Default.FormatColorText, contentDescription = "لون النص")
                }
                IconButton(onClick = onBackgroundColor) {
                    Icon(Icons.Default.FormatColorFill, contentDescription = "لون الخلفية")
                }
                IconButton(onClick = onIncreaseFont) {
                    Icon(Icons.Default.TextIncrease, contentDescription = "تكبير الخط")
                }
                IconButton(onClick = onDecreaseFont) {
                    Icon(Icons.Default.TextDecrease, contentDescription = "تصغير الخط")
                }
            }
        }
    }
}
