package com.alwsabi.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.navigation.AlWasabiNavGraph
import com.alwsabi.editor.ui.screens.settings.SettingsViewModel
import com.alwsabi.editor.ui.theme.AlWasabiTheme

/**
 * نقطة الدخول الوحيدة للتطبيق. تُبقي المنطق هنا في الحد الأدنى، وتترك
 * كل التنقل والحالة لطبقات Compose/ViewModel، لضمان عدم توقف التطبيق
 * عند التشغيل حتى في حال حدوث استثناء في شاشة فرعية.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settingsViewModel: SettingsViewModel = viewModel()
            val settings by settingsViewModel.settings.collectAsState()

            AlWasabiTheme(themeMode = settings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AlWasabiNavGraph()
                }
            }
        }
    }
}
