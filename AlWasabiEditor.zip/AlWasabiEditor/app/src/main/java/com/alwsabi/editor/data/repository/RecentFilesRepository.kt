package com.alwsabi.editor.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.alwsabi.editor.data.model.RecentDocument
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.recentDataStore by preferencesDataStore(name = "alwasabi_recent_files")

/**
 * يحتفظ بقائمة آخر الملفات التي تم فتحها أو حفظها، لعرضها في الشاشة الرئيسية.
 * كل عنصر مخزّن كسطر واحد يحتوي: uri|||الاسم|||الوقت|||mimeType
 */
class RecentFilesRepository(private val context: Context) {

    private object Keys {
        val ENTRIES = stringSetPreferencesKey("recent_entries")
    }

    private val separator = "|||"
    private val maxEntries = 20

    val recentFilesFlow: Flow<List<RecentDocument>> = context.recentDataStore.data.map { prefs ->
        val raw = prefs[Keys.ENTRIES] ?: emptySet()
        raw.mapNotNull { entry ->
            val parts = entry.split(separator)
            if (parts.size == 4) {
                RecentDocument(
                    uriString = parts[0],
                    displayName = parts[1],
                    lastOpenedMillis = parts[2].toLongOrNull() ?: 0L,
                    mimeType = parts[3]
                )
            } else null
        }.sortedByDescending { it.lastOpenedMillis }
    }

    suspend fun addOrUpdate(doc: RecentDocument) {
        context.recentDataStore.edit { prefs ->
            val current = (prefs[Keys.ENTRIES] ?: emptySet()).toMutableSet()
            current.removeAll { it.startsWith(doc.uriString + separator) }
            current.add(
                "${doc.uriString}$separator${doc.displayName}$separator${doc.lastOpenedMillis}$separator${doc.mimeType}"
            )
            val trimmed = current
                .mapNotNull { entry ->
                    val parts = entry.split(separator)
                    if (parts.size == 4) entry to (parts[2].toLongOrNull() ?: 0L) else null
                }
                .sortedByDescending { it.second }
                .take(maxEntries)
                .map { it.first }
                .toSet()
            prefs[Keys.ENTRIES] = trimmed
        }
    }

    suspend fun remove(uriString: String) {
        context.recentDataStore.edit { prefs ->
            val current = (prefs[Keys.ENTRIES] ?: emptySet()).toMutableSet()
            current.removeAll { it.startsWith(uriString + separator) }
            prefs[Keys.ENTRIES] = current
        }
    }

    suspend fun clear() {
        context.recentDataStore.edit { it[Keys.ENTRIES] = emptySet() }
    }
}
