package com.alwsabi.editor.data.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * يصدّر نصًا (مع تنسيقه إن وُجد عبر CharSequence منسّق) إلى ملف PDF حقيقي
 * باستخدام android.graphics.pdf.PdfDocument، وهو API أصلي مستقر
 * بدون أي اعتماد على مكتبات خارجية قد تسبب مشاكل بناء.
 */
class PdfExporter(private val context: Context) {

    private val pageWidthPx = 595  // A4 عند 72dpi تقريبًا
    private val pageHeightPx = 842
    private val marginPx = 40

    suspend fun exportToPdf(text: CharSequence, fontSizePx: Float, isRtl: Boolean, outputFileName: String): Result<File> =
        withContext(Dispatchers.Default) {
            try {
                val document = PdfDocument()
                val textPaint = TextPaint().apply {
                    isAntiAlias = true
                    textSize = fontSizePx
                    color = android.graphics.Color.BLACK
                }

                val contentWidth = pageWidthPx - (marginPx * 2)
                val alignment = if (isRtl) {
                    Layout.Alignment.ALIGN_NORMAL
                } else {
                    Layout.Alignment.ALIGN_NORMAL
                }

                val builder = StaticLayout.Builder.obtain(text, 0, text.length, textPaint, contentWidth)
                    .setAlignment(alignment)
                    .setLineSpacing(1.1f, 1.15f)
                    .setIncludePad(false)

                val fullLayout = builder.build()

                var currentLine = 0
                var pageNumber = 1
                val totalLines = fullLayout.lineCount

                while (currentLine < totalLines) {
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidthPx, pageHeightPx, pageNumber).create()
                    val page = document.startPage(pageInfo)
                    val canvas = page.canvas

                    canvas.translate(marginPx.toFloat(), marginPx.toFloat())

                    val availableHeight = pageHeightPx - (marginPx * 2)
                    var usedHeight = 0
                    var linesOnPage = 0

                    while (currentLine + linesOnPage < totalLines) {
                        val lineBottom = fullLayout.getLineBottom(currentLine + linesOnPage)
                        val lineTop = fullLayout.getLineTop(currentLine)
                        if (lineBottom - lineTop > availableHeight) break
                        usedHeight = lineBottom - lineTop
                        linesOnPage++
                    }
                    if (linesOnPage == 0) linesOnPage = 1

                    val startOffset = fullLayout.getLineStart(currentLine)
                    val endLineIndex = (currentLine + linesOnPage - 1).coerceAtMost(totalLines - 1)
                    val endOffset = fullLayout.getLineEnd(endLineIndex)

                    val pageText = text.subSequence(startOffset, endOffset)
                    val pageLayout = StaticLayout.Builder.obtain(pageText, 0, pageText.length, textPaint, contentWidth)
                        .setAlignment(alignment)
                        .setLineSpacing(1.1f, 1.15f)
                        .setIncludePad(false)
                        .build()
                    pageLayout.draw(canvas)

                    document.finishPage(page)
                    currentLine += linesOnPage
                    pageNumber++

                    if (pageNumber > 500) break // حماية من حلقة لا نهائية في حال محتوى غير متوقع
                }

                val outDir = File(context.cacheDir, "shared").apply { mkdirs() }
                val outFile = File(outDir, outputFileName)
                FileOutputStream(outFile).use { document.writeTo(it) }
                document.close()

                Result.success(outFile)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
