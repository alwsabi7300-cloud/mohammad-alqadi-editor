package com.alwsabi.editor.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alwsabi.editor.BuildConfig
import com.alwsabi.editor.R
import com.alwsabi.editor.data.model.TextDirectionSetting
import com.alwsabi.editor.data.model.ThemeMode
import com.alwsabi.editor.ui.components.AppTopBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    settingsViewModel: SettingsViewModel = viewModel()
) {
    val settings by settingsViewModel.settings.collectAsState()

    Scaffold(
        topBar = {
            AppTopBar(
                title = stringResource(R.string.settings_title),
                showBackButton = true,
                onBackClick = onNavigateBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ThemeOptionRow(
                label = stringResource(R.string.settings_theme_light),
                selected = settings.themeMode == ThemeMode.LIGHT,
                onSelect = { settingsViewModel.setThemeMode(ThemeMode.LIGHT) }
            )
            ThemeOptionRow(
                label = stringResource(R.string.settings_theme_dark),
                selected = settings.themeMode == ThemeMode.DARK,
                onSelect = { settingsViewModel.setThemeMode(ThemeMode.DARK) }
            )
            ThemeOptionRow(
                label = stringResource(R.string.settings_theme_system),
                selected = settings.themeMode == ThemeMode.SYSTEM,
                onSelect = { settingsViewModel.setThemeMode(ThemeMode.SYSTEM) }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text(stringResource(R.string.settings_font_size), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text("${settings.defaultFontSize}sp", style = MaterialTheme.typography.bodyMedium)
            Slider(
                value = settings.defaultFontSize.toFloat(),
                onValueChange = { settingsViewModel.setFontSize(it.toInt()) },
                valueRange = 12f..32f,
                steps = 19
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text(stringResource(R.string.settings_text_direction), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ThemeOptionRow(
                label = stringResource(R.string.settings_direction_rtl),
                selected = settings.textDirection == TextDirectionSetting.RTL,
                onSelect = { settingsViewModel.setTextDirection(TextDirectionSetting.RTL) }
            )
            ThemeOptionRow(
                label = stringResource(R.string.settings_direction_ltr),
                selected = settings.textDirection == TextDirectionSetting.LTR,
                onSelect = { settingsViewModel.setTextDirection(TextDirectionSetting.LTR) }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.settings_autosave), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_autosave_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Switch(
                    checked = settings.autoSaveEnabled,
                    onCheckedChange = { settingsViewModel.setAutoSave(it) }
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text(stringResource(R.string.settings_about_section), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "${stringResource(R.string.settings_version)}: ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ThemeOptionRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Spacer(Modifier.padding(horizontal = 4.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
