package com.alwsabi.editor.ui.theme

import androidx.compose.ui.graphics.Color

val WasabiGreen = Color(0xFF4C9A6A)
val WasabiGreenDark = Color(0xFF2E6B45)
val WasabiGreenLight = Color(0xFF7FC49A)

val WasabiBackgroundLight = Color(0xFFFFFFFF)
val WasabiSurfaceLight = Color(0xFFF5F7F5)
val WasabiOnBackgroundLight = Color(0xFF1A1C1A)

val WasabiBackgroundDark = Color(0xFF121212)
val WasabiSurfaceDark = Color(0xFF1E1F1E)
val WasabiOnBackgroundDark = Color(0xFFEAEAEA)

val WasabiError = Color(0xFFBA1A1A)
val WasabiErrorDark = Color(0xFFFFB4AB)
